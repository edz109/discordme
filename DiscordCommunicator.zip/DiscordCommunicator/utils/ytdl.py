import asyncio
import discord
import logging
import yt_dlp

logger = logging.getLogger("MusicBot.YTDL")

# Configure yt-dlp options - OPTIMIZED FOR DIRECT AUDIO EXTRACTION
YTDL_FORMAT_OPTIONS = {
    'format': 'bestaudio/best',  # Improved format selection strategy
    'extractaudio': True,        # Extract audio
    'audioformat': 'mp3',        # Convert to mp3
    'noplaylist': True,
    'nocheckcertificate': True,
    'ignoreerrors': False,
    'logtostderr': False,
    'quiet': True,
    'no_warnings': True,
    'default_search': 'ytsearch',  # Force YouTube search for better reliability
    'source_address': '0.0.0.0',
    # Speed optimizations
    'socket_timeout': 5,         # Slightly longer timeout for reliability
    'extract_flat': False,       # Extract full info for direct URLs
    'skip_download': True,       # Skip downloading the file
    'cachedir': False,           # Disable cache to avoid slow disk operations
    # Format selection optimizations
    'youtube_include_dash_manifest': False,  # Skip slow DASH manifest processing
    'youtube_include_hls_manifest': False,   # Skip slow HLS manifest processing
    # Important: Don't force any ytdl format; let it choose the best one
}

# Simplified FFmpeg options for reliable playback
FFMPEG_OPTIONS = {
    # Basic audio extraction with minimal processing to ensure compatibility
    # Using simple volume boost without complex filters that might cause issues
    'options': '-vn -af "volume=1.5"',
    
    # Essential connection settings for reliability:
    # Keep only the most important options that ensure stable connections
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5 -http_persistent 0 -y',
}

# Create a youtube_dl client
ytdl = yt_dlp.YoutubeDL(YTDL_FORMAT_OPTIONS)

class YTDLSource(discord.PCMVolumeTransformer):
    def __init__(self, source, *, data, volume=1.0):
        super().__init__(source, volume)
        self.data = data
        self.title = data.get('title')
        self.url = data.get('webpage_url', data.get('url', ''))
        # Set a higher volume by default
        self.volume = 1.0

    @classmethod
    async def search_youtube(cls, query, *, loop=None):
        """Search for a YouTube video and return the first result with optimized speed"""
        loop = loop or asyncio.get_event_loop()
        
        # Create special search options optimized for SPEED
        search_options = {
            'format': 'bestaudio',
            'noplaylist': True,
            'nocheckcertificate': True,
            'ignoreerrors': False,
            'quiet': True,
            'no_warnings': True,
            'default_search': 'ytsearch',  # Force YouTube search
            'source_address': '0.0.0.0',
            # Speed optimizations
            'extract_flat': 'in_playlist',  # Only get essential info (much faster)
            'skip_download': True,
            'cachedir': False,           # Disable cache for faster response
            'socket_timeout': 3,         # Shorter timeout
            'limit': 1,                  # Only get one result (faster)
            # Skip slow format processing
            'youtube_include_dash_manifest': False,
            'youtube_include_hls_manifest': False,
        }
        
        try:
            # Use a faster approach with timeout
            with yt_dlp.YoutubeDL(search_options) as ydl:
                logger.info(f"Fast searching YouTube for: {query}")
                search_query = f"ytsearch1:{query}"  # Limit to 1 result
                
                # Run with timeout for faster response
                data = await asyncio.wait_for(
                    loop.run_in_executor(None, lambda: ydl.extract_info(search_query, download=False)),
                    timeout=5.0  # 5 second timeout
                )
                
                if not data or not data.get("entries"):
                    logger.warning(f"No results found for query: {query}")
                    return None
                
                # Get first search result and ensure it has essential data
                result = data["entries"][0]
                
                # Make sure we have the minimum needed data
                if not result.get('title'):
                    result['title'] = query
                
                logger.info(f"Fast search found: {result.get('title', 'Unknown')}")
                return result
                
        except asyncio.TimeoutError:
            logger.warning(f"Search timed out for: {query}")
            # Create minimal result with just a title if we time out
            return {
                'title': f"Search result for: {query}",
                'url': None,
                'webpage_url': None
            }
            
        except Exception as e:
            logger.error(f"Error searching YouTube: {e}", exc_info=e)
            # Return None instead of raising exception for smoother error handling
            return None
    
    @classmethod
    async def get_info(cls, url, *, loop=None):
        """Get information about a YouTube video or search query"""
        loop = loop or asyncio.get_event_loop()
        
        # Handle YouTube search queries differently
        if url.startswith("ytsearch:"):
            query = url[9:]  # Remove "ytsearch:" prefix
            logger.info(f"Converting to YouTube search: {query}")
            result = await cls.search_youtube(query, loop=loop)
            if result:
                return result
            else:
                raise Exception(f"No search results found for: {query}")
        
        # Special handling for Spotify URLs
        if "spotify.com" in url:
            logger.info(f"Processing Spotify URL: {url}")
            
            # Extract artist and track name if possible from the Spotify URL
            try:
                # Try to extract track info from URL
                import re
                # Try to get the track title from the URL
                track_id = url.split('/')[-1].split('?')[0]
                
                # Check if we have spotdl installed for better handling
                try:
                    import importlib.util
                    spotdl_spec = importlib.util.find_spec("spotdl")
                    if spotdl_spec:
                        logger.info("Spotdl found, using it for Spotify conversion")
                        # We could add direct spotdl integration here in future
                    else:
                        logger.warning("No spotdl found, using fallback method")
                except ImportError:
                    logger.warning("Error importing spotdl")
                
                # Fallback - just search for the track ID
                logger.info(f"Searching YouTube for Spotify track: {track_id}")
                search_query = f"spotify track {track_id}"
                return await cls.search_youtube(search_query, loop=loop)
                
            except Exception as e:
                logger.error(f"Error processing Spotify URL: {e}", exc_info=e)
                # Just search for the URL as a fallback
                return await cls.search_youtube(url, loop=loop)
        
        # Handle direct URLs
        try:
            data = await loop.run_in_executor(None, lambda: ytdl.extract_info(url, download=False))
            
            # Take the first entry if it's a playlist or search result
            if 'entries' in data:
                data = data['entries'][0]
                
            return data
        except yt_dlp.utils.DownloadError as e:
            logger.error(f"Error extracting info: {e}", exc_info=e)
            
            # If extraction failed, try to search instead as fallback
            logger.info(f"Trying search as fallback for: {url}")
            try:
                return await cls.search_youtube(url, loop=loop)
            except Exception as search_error:
                logger.error(f"Fallback search also failed: {search_error}")
                raise Exception(f"Could not extract video information: {e}")
                
        except Exception as e:
            logger.error(f"Unexpected error extracting info: {e}", exc_info=e)
            raise Exception(f"An error occurred: {e}")

    @classmethod
    async def from_url(cls, url, *, loop=None, stream=False):
        """Create an audio source from a YouTube URL using a reliable approach"""
        loop = loop or asyncio.get_event_loop()
        
        try:
            # Always stream for playback
            stream = True
            logger.info(f"Getting info for URL: {url}")
            
            # For YouTube URLs, use a modified approach to get direct stream URL
            is_youtube = False
            if 'youtube.com' in url or 'youtu.be' in url:
                is_youtube = True
                logger.info("Direct YouTube URL detected, using optimized extraction")
            
            # Handle search queries differently and efficiently
            if url.startswith("ytsearch:"):
                query = url[9:]  # Remove "ytsearch:" prefix
                logger.info(f"Search query detected in from_url: {query}")
                
                # Enhanced extraction options for search
                extract_options = {
                    'format': 'bestaudio/best',
                    'noplaylist': True,
                    'nocheckcertificate': True,
                    'ignoreerrors': False,
                    'quiet': True,
                    'no_warnings': True,
                    'extractaudio': True,
                    'skip_download': True,
                    'default_search': 'ytsearch1',  # Force single result
                }
                
                try:
                    # Direct yt-dlp extraction for more reliable audio URLs
                    with yt_dlp.YoutubeDL(extract_options) as ydl:
                        logger.info(f"Directly extracting audio URL for: {query}")
                        data = await loop.run_in_executor(None, lambda: ydl.extract_info(query, download=False))
                        
                        # Process the entry from search results
                        if 'entries' in data and data['entries']:
                            data = data['entries'][0]
                        
                        # Store the video ID and title from search
                        video_id = data.get('id')
                        title = data.get('title', query)
                        
                        logger.info(f"Found video ID: {video_id} for '{title}'")
                except Exception as search_error:
                    logger.error(f"Error in search extraction: {search_error}")
                    raise Exception(f"Search failed: {str(search_error)}")
            
            # Special handling for Spotify URLs
            elif "spotify.com" in url:
                logger.info(f"Spotify URL detected in from_url: {url}")
                
                # Better spotify extraction options
                extract_options = {
                    'format': 'bestaudio/best',
                    'noplaylist': True,
                    'nocheckcertificate': True,
                    'extractaudio': True,
                    'quiet': True,
                    'default_search': 'ytsearch',
                }
                
                # Extract track title and artist if possible
                try:
                    # Get track ID for searching
                    track_id = url.split('/')[-1].split('?')[0]
                    search_query = f"ytsearch1:spotify track {track_id}"
                    
                    with yt_dlp.YoutubeDL(extract_options) as ydl:
                        logger.info(f"Extracting from Spotify track ID: {track_id}")
                        data = await loop.run_in_executor(None, lambda: ydl.extract_info(search_query, download=False))
                        
                        # Process search result
                        if 'entries' in data and data['entries']:
                            data = data['entries'][0]
                except Exception as spotify_error:
                    logger.error(f"Spotify extraction failed: {spotify_error}")
                    raise Exception(f"Could not process Spotify track: {str(spotify_error)}")
            
            # For all other URLs (including direct YouTube)
            else:
                extract_options = {
                    'format': 'bestaudio/best',
                    'noplaylist': True, 
                    'nocheckcertificate': True,
                    'ignoreerrors': False,
                    'quiet': True,
                    'extractaudio': True,
                    'skip_download': True,
                }
                
                try:
                    with yt_dlp.YoutubeDL(extract_options) as ydl:
                        # Extract with more reliable settings
                        data = await loop.run_in_executor(None, lambda: ydl.extract_info(url, download=False))
                        
                        # Handle playlist or multiple results
                        if 'entries' in data and data['entries']:
                            data = data['entries'][0]
                except Exception as extract_error:
                    logger.error(f"URL extraction failed: {extract_error}")
                    raise Exception(f"Could not extract audio from URL: {str(extract_error)}")
            
            # Find the best audio format URL
            direct_url = None
            
            # First try direct URL field
            if data.get('url'):
                direct_url = data['url']
                logger.info("Using direct audio URL from data")
            
            # Then check available formats for best audio
            elif 'formats' in data and data['formats']:
                logger.info(f"Searching through {len(data['formats'])} available formats")
                
                # First try to find audio-only format (most reliable for discord.py)
                audio_formats = []
                for fmt in data['formats']:
                    if isinstance(fmt, dict):
                        # Check if it's an audio format
                        if fmt.get('acodec') != 'none' and (
                            fmt.get('vcodec') == 'none' or 
                            'audio only' in fmt.get('format', '')
                        ):
                            audio_formats.append(fmt)
                
                # Sort audio formats by quality (typically higher bitrate = better)
                if audio_formats:
                    # Sort by bitrate (higher first)
                    audio_formats.sort(key=lambda x: x.get('abr', 0), reverse=True)
                    best_audio = audio_formats[0]
                    direct_url = best_audio.get('url')
                    logger.info(f"Using best audio format: {best_audio.get('format_id')}")
                
                # If no audio-only format, use the first available format
                if not direct_url and isinstance(data['formats'][0], dict):
                    direct_url = data['formats'][0].get('url')
                    logger.info("Using first available format URL")
            
            # Last resort - try to get any URL we can
            if not direct_url:
                # For youtube, we can try a special extraction
                if is_youtube or data.get('webpage_url', '').startswith('https://www.youtube.com/'):
                    video_id = data.get('id') or data.get('webpage_url', '').split('v=')[-1].split('&')[0]
                    if video_id:
                        logger.info(f"Using specialized extraction for YouTube ID: {video_id}")
                        try:
                            # Try a more targeted extraction
                            youtube_url = f"https://www.youtube.com/watch?v={video_id}"
                            with yt_dlp.YoutubeDL({'format': 'bestaudio', 'quiet': True}) as ydl:
                                new_data = await loop.run_in_executor(None, lambda: ydl.extract_info(youtube_url, download=False))
                                if new_data and new_data.get('url'):
                                    direct_url = new_data['url']
                                    logger.info("Successfully extracted direct audio URL")
                        except Exception as yt_error:
                            logger.warning(f"YouTube special extraction failed: {yt_error}")
            
            # If we still don't have a URL, raise an error
            if not direct_url:
                logger.error("Could not find any usable audio URL")
                raise Exception("No audio stream URL found. Try a different search query or link.")
            
            # Create a simplified audio source for better reliability
            try:
                logger.info(f"Using audio URL: {direct_url[:30]}...")
                source = discord.FFmpegPCMAudio(direct_url, **FFMPEG_OPTIONS)
                logger.info("Successfully created FFmpeg PCM audio source")
                
                # Create a volume transformer with default volume
                player = cls(source, data=data, volume=1.0)
                logger.info(f"Created audio player with volume: {player.volume}")
                return player
                
            except Exception as audio_error:
                logger.error(f"Failed to create audio source: {audio_error}")
                raise Exception(f"Could not create audio player: {str(audio_error)}")
            
        except Exception as e:
            logger.error(f"Error in from_url: {str(e)}")
            raise Exception(f"Could not process the audio: {str(e)}")