import asyncio
import discord
from discord.ext import commands
from discord import app_commands
import logging
import re
import urllib.parse
from typing import Dict, List, Optional

from utils.ytdl import YTDLSource

class Music(commands.Cog):
    """Music commands for playing songs from YouTube"""
    
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger("MusicBot.Music")
        self.queues: Dict[int, List[Dict]] = {}  # Guild ID -> list of songs
        self.currently_playing: Dict[int, Dict] = {}  # Guild ID -> current song info
        self.voice_clients: Dict[int, discord.VoiceClient] = {}  # Guild ID -> voice client
        self.task_queues: Dict[int, asyncio.Task] = {}  # Guild ID -> queue processing task
        
        # Load opus library - radio mode if not available
        try:
            import glob
            if not discord.opus.is_loaded():
                # Use the exact known paths from the newly installed libopus
                specific_opus_paths = [
                    "/nix/store/235dxwql4lqrfjfhqrld8i3pwcffhwxf-libopus-1.4/lib/libopus.so.0.9.0",
                    "/nix/store/2kchsa3wq48s5gwnrrkjzikrapmw3j41-libopus-1.4/lib/libopus.so.0.9.0",
                    "/nix/store/2m0ngng1iy80h65052chw7mn18qbgq0w-libopus-1.5.2/lib/libopus.so.0.10.1",
                    "/nix/store/2imbl1vr40yn4lcza7cgdpr98ka7zwxb-libopus-1.3.1/lib/libopus.so.0.8.0"
                ]
                
                # Try the specific paths first
                for path in specific_opus_paths:
                    try:
                        self.logger.info(f"Trying to load Opus from: {path}")
                        discord.opus.load_opus(path)
                        if discord.opus.is_loaded():
                            self.logger.info(f"Successfully loaded Opus from: {path}")
                            break
                    except Exception as e:
                        self.logger.debug(f"Failed to load {path}: {e}")
                        continue
                
                # If still not loaded, search nix store for opus library
                if not discord.opus.is_loaded():
                    self.logger.info("Specific paths failed, searching nix store...")
                    opus_paths = glob.glob('/nix/store/*-libopus-*/lib/libopus.so*')
                    
                    for path in opus_paths:
                        try:
                            self.logger.info(f"Trying to load Opus from: {path}")
                            discord.opus.load_opus(path)
                            if discord.opus.is_loaded():
                                self.logger.info(f"Successfully loaded Opus from: {path}")
                                break
                        except Exception as e:
                            self.logger.debug(f"Failed to load {path}: {e}")
                            continue
                
                # If still not loaded, try common names
                if not discord.opus.is_loaded():
                    self.logger.info("Nix store search failed, trying common library names...")
                    opus_names = ['libopus.so.0', 'libopus.so', 'libopus']
                    for name in opus_names:
                        try:
                            self.logger.info(f"Trying to load Opus from: {name}")
                            discord.opus.load_opus(name)
                            if discord.opus.is_loaded():
                                self.logger.info(f"Successfully loaded Opus from: {name}")
                                break
                        except Exception as e:
                            self.logger.debug(f"Failed to load {name}: {e}")
                            continue
                
                # Last resort - try default loading
                if not discord.opus.is_loaded():
                    self.logger.info("Trying default Opus loading mechanism...")
                    try:
                        discord.opus._load_default()
                        if discord.opus.is_loaded():
                            self.logger.info("Successfully loaded Opus with default mechanism")
                    except Exception as e:
                        self.logger.debug(f"Default loading failed: {e}")
            
            if discord.opus.is_loaded():
                self.logger.info("Opus library loaded successfully - enabling direct audio playback")
                if hasattr(self.bot, 'radio_mode'):
                    self.bot.radio_mode = False
            else:
                raise Exception("Could not find Opus library, please make sure libopus is installed")
                
        except Exception as e:
            self.logger.warning(f"Failed to load Opus library, switching to radio mode: {e}")
            if hasattr(self.bot, 'radio_mode'):
                self.bot.radio_mode = True
                self.logger.info("Radio mode enabled - bot will provide links instead of direct playback")
        
    def get_queue(self, guild_id: int) -> List[Dict]:
        """Get the queue for a guild, creating it if it doesn't exist"""
        if guild_id not in self.queues:
            self.queues[guild_id] = []
        return self.queues[guild_id]
    
    async def cleanup(self, guild_id: int):
        """Clean up resources for a guild"""
        # Clear the currently playing song
        if guild_id in self.currently_playing:
            del self.currently_playing[guild_id]
        
        # Cancel any queue processing task
        if guild_id in self.task_queues:
            self.task_queues[guild_id].cancel()
            del self.task_queues[guild_id]
            
        # Disconnect from voice channel
        if guild_id in self.voice_clients:
            await self.voice_clients[guild_id].disconnect()
            del self.voice_clients[guild_id]
    
    async def process_queue(self, ctx, guild_id: int):
        """Process the song queue for a guild"""
        queue = self.get_queue(guild_id)
        voice_client = self.voice_clients.get(guild_id)
        
        try:
            while queue and voice_client and voice_client.is_connected():
                # Get the next song from the queue
                song = queue.pop(0)
                self.currently_playing[guild_id] = song
                
                # Check if we're in radio mode
                if hasattr(self.bot, 'radio_mode') and self.bot.radio_mode:
                    # In radio mode, we just send a link to the song instead of playing it
                    embed = discord.Embed(
                        title="🎵 Now Playing (Radio Mode)",
                        description=f"**{song['title']}**",
                        color=discord.Color.blue()
                    )
                    embed.add_field(name="Requested by", value=song['requester'], inline=True)
                    embed.add_field(name="Listen on YouTube", value=f"[Click here]({song['url']})", inline=True)
                    if song.get('thumbnail'):
                        embed.set_thumbnail(url=song['thumbnail'])
                    
                    await ctx.send(embed=embed)
                    
                    # Wait a bit before processing the next song
                    await asyncio.sleep(3)
                    
                    # Mark as processed
                    continue
                
                # Standard mode - try to play audio
                await ctx.send(f"🎵 Now playing: **{song['title']}**")
                
                try:
                    # Create an audio source from the song
                    try:
                        self.logger.info(f"Creating audio source for: {song['title']}")
                        
                        # Use the improved YouTube search for better reliability
                        if song['source'] == "Search Query":
                            # Extract the video title for more accurate YouTube search
                            search_term = song['title']
                            self.logger.info(f"Using title-based search for better accuracy: {search_term}")
                            player = await YTDLSource.from_url(f"ytsearch:{search_term}", loop=self.bot.loop, stream=True)
                        else:
                            # Use the direct URL for other sources
                            player = await YTDLSource.from_url(song['url'], loop=self.bot.loop, stream=True)
                        
                        # Play the song with improved error handling
                        def after_callback(error):
                            if error:
                                self.logger.error(f"Player error: {error}", exc_info=error)
                                asyncio.run_coroutine_threadsafe(
                                    ctx.send(f"❌ Error playing song: {error}"), 
                                    self.bot.loop
                                )
                            
                        # Set volume to ensure audio is loud enough but not distorted (100% volume)
                        player.volume = 1.0
                        
                        # Configure playback for better stability
                        voice_client.stop()  # Stop any existing playback
                        
                        # Start playback with enhanced buffer options
                        self.logger.info(f"Starting playback with volume: {player.volume}")
                        voice_client.play(player, after=after_callback)
                        
                        # Apply audio buffering settings to voice client
                        if hasattr(voice_client, '_player') and voice_client._player:
                            try:
                                # Adjust buffer settings to reduce lag
                                voice_client._player.delay = 0.06  # Slight increase in buffer to prevent stuttering
                                self.logger.info(f"Updated player buffer settings for smoother playback")
                            except Exception as buffer_error:
                                self.logger.warning(f"Could not update buffer settings: {buffer_error}")
                        
                        # Log successful playback start
                        self.logger.info(f"Playback started successfully for: {song['title']}")
                        
                    except discord.opus.OpusNotLoaded as opus_error:
                        self.logger.error(f"Opus library error: {opus_error}", exc_info=opus_error)
                        await ctx.send(f"❌ Cannot play audio: Opus library not available.")
                        await ctx.send(f"🔗 Listen here instead: {song['url']}")
                        # Skip this song and try the next one
                        continue
                    except Exception as e:
                        self.logger.error(f"Error starting playback: {e}", exc_info=e)
                        await ctx.send(f"❌ Failed to play audio: {e}")
                        await ctx.send(f"🔗 Listen here instead: {song['url']}")
                        # Skip this song and try the next one
                        continue
                    
                    # Wait for the song to finish
                    while voice_client.is_playing() or voice_client.is_paused():
                        await asyncio.sleep(1)
                        
                except Exception as e:
                    self.logger.error(f"Error playing song: {e}", exc_info=e)
                    await ctx.send(f"❌ Error playing song: {e}")
                    await ctx.send(f"🔗 Listen here instead: {song['url']}")
                    await asyncio.sleep(3)  # Wait a bit before trying the next song
                
                # Clear currently playing if the queue is empty
                if not queue:
                    self.currently_playing.pop(guild_id, None)
                    
        except asyncio.CancelledError:
            self.logger.info(f"Queue processing task cancelled for guild {guild_id}")
        except Exception as e:
            self.logger.error(f"Error processing queue: {e}", exc_info=e)
            await ctx.send(f"An error occurred while playing music: {e}")
        finally:
            # Clear the task from the dict when done
            self.task_queues.pop(guild_id, None)
    
    async def join_voice_channel(self, interaction, member):
        """Join the user's voice channel and return the voice client or None if failed"""
        if not member.voice:
            await interaction.response.send_message("You are not connected to a voice channel.")
            return None
        
        channel = member.voice.channel
        
        # Check if already connected to a voice channel
        if interaction.guild.id in self.voice_clients:
            voice_client = self.voice_clients[interaction.guild.id]
            if voice_client.channel.id == channel.id:
                await interaction.response.send_message(f"Already connected to {channel.name}.")
                return voice_client
            await voice_client.move_to(channel)
            await interaction.response.send_message(f"Moved to {channel.name}.")
            return voice_client
        
        # Connect to voice channel
        try:
            voice_client = await channel.connect()
            self.voice_clients[interaction.guild.id] = voice_client
            await interaction.response.send_message(f"Connected to {channel.name}.")
            return voice_client
        except Exception as e:
            self.logger.error(f"Error joining voice channel: {e}", exc_info=e)
            await interaction.response.send_message(f"Could not join voice channel: {e}")
            return None

    @app_commands.command(name="join", description="Join your voice channel")
    async def join(self, interaction: discord.Interaction):
        """Join the user's voice channel"""
        # Add additional debug logging
        self.logger.info(f"Join command received from {interaction.user} in guild {interaction.guild.name}")
        
        # Check if user is in a voice channel
        if not interaction.user.voice:
            self.logger.warning(f"User {interaction.user} is not in a voice channel")
            await interaction.response.send_message("❌ You need to be in a voice channel first.")
            return
            
        # Check if we are already connected to a voice channel in this guild
        if interaction.guild.voice_client:
            if interaction.guild.voice_client.channel == interaction.user.voice.channel:
                self.logger.info(f"Already connected to {interaction.user.voice.channel.name}")
                await interaction.response.send_message(f"✅ Already connected to {interaction.user.voice.channel.name}")
                return
            
            # We're connected to a different channel, move to the user's channel
            try:
                self.logger.info(f"Moving from {interaction.guild.voice_client.channel.name} to {interaction.user.voice.channel.name}")
                await interaction.guild.voice_client.move_to(interaction.user.voice.channel)
                self.logger.info(f"Successfully moved to {interaction.user.voice.channel.name}")
                await interaction.response.send_message(f"✅ Moved to {interaction.user.voice.channel.name}")
                return
            except Exception as e:
                self.logger.error(f"Error moving to voice channel: {e}", exc_info=True)
                await interaction.response.send_message(f"❌ Error moving to your voice channel: {e}")
                return
        
        # Connect to the voice channel
        try:
            self.logger.info(f"Connecting to voice channel: {interaction.user.voice.channel.name}")
            # Use a more direct approach to connect
            voice_client = await interaction.user.voice.channel.connect(timeout=20.0, reconnect=True)
            self.logger.info(f"Connection successful, storing voice client")
            
            # Store the voice client in our dictionary
            self.voice_clients[interaction.guild.id] = voice_client
            
            await interaction.response.send_message(f"✅ Connected to {interaction.user.voice.channel.name}")
            self.logger.info(f"Successfully joined {interaction.user.voice.channel.name}")
        except Exception as e:
            self.logger.error(f"Error joining voice channel: {e}", exc_info=True)
            await interaction.response.send_message(f"❌ Could not join voice channel: {str(e)}")
    
    def detect_music_service(self, query: str):
        """Detect the music service from a URL and properly format for yt-dlp"""
        # YouTube URL pattern
        if re.match(r"^(https?://)?(www\.)?(youtube\.com|youtu\.be)/.+", query):
            self.logger.info(f"Detected YouTube URL: {query}")
            return query, "YouTube"
            
        # Spotify URL pattern
        if re.match(r"^(https?://)?(open\.)?spotify\.com/.+", query):
            self.logger.info(f"Detected Spotify URL: {query}")
            
            # If spotdl is imported, we could use it directly
            # For now, treat it as a normal URL and rely on yt-dlp to handle it
            try:
                import importlib.util
                if importlib.util.find_spec("spotdl"):
                    self.logger.info("spotdl package is available for Spotify conversion")
                else:
                    self.logger.warning("spotdl package is not available, using fallback")
            except ImportError:
                self.logger.warning("Error checking for spotdl package")
                
            return query, "Spotify"
            
        # SoundCloud URL pattern
        if re.match(r"^(https?://)?(www\.)?soundcloud\.com/.+", query):
            self.logger.info(f"Detected SoundCloud URL: {query}")
            return query, "SoundCloud"
            
        # Deezer URL pattern
        if re.match(r"^(https?://)?(www\.)?deezer\.com/.+", query):
            self.logger.info(f"Detected Deezer URL: {query}")
            return query, "Deezer"
            
        # Apple Music URL pattern
        if re.match(r"^(https?://)?(music\.)?apple\.com/.+", query):
            self.logger.info(f"Detected Apple Music URL: {query}")
            return query, "Apple Music"
            
        # If not a recognized URL, treat as a search query
        self.logger.info(f"Treating as search query: {query}")
        return f"ytsearch:{query}", "Search Query"
    
    @app_commands.command(name="search", description="Search for a song on YouTube and play the first result")
    @app_commands.describe(query="Search term to find music on YouTube")
    async def search(self, interaction: discord.Interaction, query: str):
        """Fast search for a song on YouTube and play the first result"""
        self.logger.info(f"Optimized search command used with query: {query}")
        
        # Immediately defer response to avoid timeout
        await interaction.response.defer(ephemeral=False)
        
        # Fast-track search directly to YouTube
        await interaction.followup.send(f"🔍 Searching for: `{query}`...")
        
        # Direct YouTube search for speed
        try:
            # Force the query to be treated as a direct YouTube search
            formatted_query = f"ytsearch:{query}"
            self.logger.info(f"Using optimized direct YouTube search: {formatted_query}")
            await self.play(interaction, formatted_query, force_search=True, already_deferred=True)
        except Exception as e:
            self.logger.error(f"Error in optimized search: {e}")
            await interaction.followup.send(f"❌ Search failed: {str(e)}")
    
    @app_commands.command(name="play", description="Add a song to the queue from various music platforms")
    @app_commands.describe(query="YouTube/Spotify/SoundCloud URL or search query")
    async def play(self, interaction: discord.Interaction, query: str, force_search: bool = False, already_deferred: bool = False):
        """Play a song from various music services or search query with optimized performance"""
        # Defer the response if not already done
        if not already_deferred:
            await interaction.response.defer(ephemeral=False)
        
        self.logger.info(f"Play command received from {interaction.user} with query: {query}")
        
        # Check if user is in a voice channel
        if not interaction.user.voice:
            await interaction.followup.send("❌ You need to be in a voice channel to use this command.")
            return
        
        # Join the voice channel if not already connected
        voice_client = None
        
        # Check if we're already connected to a voice channel in this guild
        if interaction.guild.voice_client:
            # We are already connected somewhere
            if interaction.guild.voice_client.channel != interaction.user.voice.channel:
                # We're in a different channel, move to the user's channel
                try:
                    self.logger.info(f"Moving from {interaction.guild.voice_client.channel.name} to {interaction.user.voice.channel.name}")
                    await interaction.guild.voice_client.move_to(interaction.user.voice.channel)
                    voice_client = interaction.guild.voice_client
                    self.voice_clients[interaction.guild.id] = voice_client
                    await interaction.followup.send(f"✅ Moved to {interaction.user.voice.channel.name}")
                except Exception as e:
                    self.logger.error(f"Error moving to voice channel: {e}", exc_info=True)
                    await interaction.followup.send(f"❌ Error moving to your voice channel: {e}")
                    return
            else:
                voice_client = interaction.guild.voice_client
                self.voice_clients[interaction.guild.id] = voice_client
        else:
            # Connect to the voice channel
            try:
                self.logger.info(f"Connecting to voice channel: {interaction.user.voice.channel.name}")
                # Use a more direct approach to connect
                voice_client = await interaction.user.voice.channel.connect(timeout=20.0, reconnect=True)
                self.voice_clients[interaction.guild.id] = voice_client
                # Don't send a message about connecting to the channel
                self.logger.info(f"Successfully joined {interaction.user.voice.channel.name}")
            except Exception as e:
                self.logger.error(f"Error joining voice channel: {e}", exc_info=True)
                await interaction.followup.send(f"❌ Could not join voice channel: {str(e)}")
                return
        
        if not voice_client or not voice_client.is_connected():
            await interaction.followup.send("❌ Failed to connect to a voice channel.")
            return
        
        # If force_search is True, always treat as a search query
        if force_search:
            self.logger.info(f"Force search enabled, treating as YouTube search: {query}")
            url = f"ytsearch:{query}"
            source_type = "Search Query"
        else:
            # Detect music service and format URL appropriately
            url, source_type = self.detect_music_service(query)
        
        # No need to send a message about searching, we'll just show the final result
        
        # Get song info
        try:
            # If it's a search query, use our specialized search method
            if url.startswith("ytsearch:"):
                query = url[9:]  # Remove "ytsearch:" prefix
                self.logger.info(f"Using specialized YouTube search for: {query}")
                song_info = await YTDLSource.search_youtube(query, loop=self.bot.loop)
                
                if not song_info:
                    await interaction.followup.send("❌ No search results found. Try a different search term.")
                    return
                    
                # Ensure song_info is not None before proceeding
                if not isinstance(song_info, dict):
                    self.logger.error(f"Invalid song_info format: {type(song_info)}")
                    await interaction.followup.send("❌ Error processing search results. Try a different search term.")
                    return
            else:
                # Regular URL processing
                song_info = await YTDLSource.get_info(url, loop=self.bot.loop)
                
                # Ensure song_info is not None before proceeding
                if not song_info or not isinstance(song_info, dict):
                    self.logger.error(f"Invalid song_info format: {type(song_info)}")
                    await interaction.followup.send("❌ Error processing media information. Please try a different URL.")
                    return
            
            # Create song object - with explicit error handling for required fields
            try:
                song = {
                    "url": song_info.get("webpage_url", url),  # Fallback to original URL if not found
                    "title": song_info.get("title", "Unknown Title"),
                    "duration": song_info.get("duration", 0),
                    "uploader": song_info.get("uploader", "Unknown"),
                    "thumbnail": song_info.get("thumbnail", ""),
                    "requester": interaction.user.name,
                    "source": source_type
                }
                
                # Log success
                self.logger.info(f"Successfully processed song info: {song['title']}")
                
            except Exception as e:
                self.logger.error(f"Error creating song object: {e}", exc_info=e)
                await interaction.followup.send(f"❌ Error processing song data: {e}")
                return
            
            # Add song to queue
            queue = self.get_queue(interaction.guild.id)
            queue.append(song)
            
            # Get queue position
            queue_position = len(queue)
            
            # Format duration
            duration_str = ""
            if song['duration']:
                minutes, seconds = divmod(int(song['duration']), 60)  # Convert to int first
                duration_str = f" ({minutes}:{seconds:02d})"
            
            # Create a simplified message with just the essential info
            await interaction.followup.send(f"**{song['title']}**{duration_str} - Position in queue: {queue_position}")
            
            # Start queue processing if not already running
            if interaction.guild.id not in self.task_queues or self.task_queues[interaction.guild.id].done():
                # We need a context-like object for the process_queue method
                class CtxLike:
                    def __init__(self, followup, guild):
                        self.followup = followup
                        self.guild = guild
                    
                    async def send(self, content=None, **kwargs):
                        await self.followup.send(content=content, **kwargs)
                
                ctx_like = CtxLike(interaction.followup, interaction.guild)
                task = asyncio.create_task(self.process_queue(ctx_like, interaction.guild.id))
                self.task_queues[interaction.guild.id] = task
                
        except Exception as e:
            self.logger.error(f"Error playing song: {e}", exc_info=e)
            await interaction.followup.send(f"An error occurred: {e}")
    
    @app_commands.command(name="pause", description="Pause the currently playing song")
    async def pause(self, interaction: discord.Interaction):
        """Pause the currently playing song"""
        voice_client = self.voice_clients.get(interaction.guild.id)
        if not voice_client or not voice_client.is_playing():
            await interaction.response.send_message("Nothing is playing right now.")
            return
            
        voice_client.pause()
        await interaction.response.send_message("⏸️ Music paused.")
    
    @app_commands.command(name="resume", description="Resume the currently paused song")
    async def resume(self, interaction: discord.Interaction):
        """Resume the currently paused song"""
        voice_client = self.voice_clients.get(interaction.guild.id)
        if not voice_client or not voice_client.is_paused():
            await interaction.response.send_message("Nothing is paused right now.")
            return
            
        voice_client.resume()
        await interaction.response.send_message("▶️ Music resumed.")
    
    @app_commands.command(name="skip", description="Skip the currently playing song")
    async def skip(self, interaction: discord.Interaction):
        """Skip the currently playing song"""
        voice_client = self.voice_clients.get(interaction.guild.id)
        if not voice_client or not voice_client.is_playing():
            await interaction.response.send_message("Nothing is playing right now.")
            return
            
        voice_client.stop()
        await interaction.response.send_message("⏭️ Skipped the current song.")
    
    @app_commands.command(name="stop", description="Stop playing music and clear the queue")
    async def stop(self, interaction: discord.Interaction):
        """Stop playing music and clear the queue"""
        # Clear the queue for this guild
        if interaction.guild.id in self.queues:
            self.queues[interaction.guild.id].clear()
        
        voice_client = self.voice_clients.get(interaction.guild.id)
        if voice_client and voice_client.is_playing():
            voice_client.stop()
        
        await self.cleanup(interaction.guild.id)
        await interaction.response.send_message("⏹️ Music stopped and queue cleared.")
    
    @app_commands.command(name="queue", description="Show the current song queue")
    async def queue(self, interaction: discord.Interaction):
        """Show the current song queue"""
        queue = self.get_queue(interaction.guild.id)
        currently_playing = self.currently_playing.get(interaction.guild.id)
        
        if not queue and not currently_playing:
            await interaction.response.send_message("The queue is empty.")
            return
        
        # Create an embed to display the queue
        embed = discord.Embed(title="Music Queue", color=discord.Color.blurple())
        
        # Add currently playing song
        if currently_playing:
            embed.add_field(
                name="Now Playing",
                value=f"**{currently_playing['title']}** (requested by {currently_playing['requester']})",
                inline=False
            )
        
        # Add queued songs
        if queue:
            queue_text = ""
            for i, song in enumerate(queue, 1):
                queue_text += f"{i}. **{song['title']}** (requested by {song['requester']})\n"
                # Prevent embed from getting too long
                if i >= 10:
                    queue_text += f"...and {len(queue) - 10} more songs."
                    break
            
            embed.add_field(name="Queue", value=queue_text, inline=False)
        
        embed.set_footer(text=f"Total songs in queue: {len(queue)}")
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="nowplaying", description="Show information about the currently playing song")
    async def now_playing(self, interaction: discord.Interaction):
        """Show information about the currently playing song"""
        currently_playing = self.currently_playing.get(interaction.guild.id)
        if not currently_playing:
            await interaction.response.send_message("Nothing is playing right now.")
            return
        
        # Create an embed with song information
        embed = discord.Embed(
            title="Now Playing",
            description=f"**{currently_playing['title']}**",
            color=discord.Color.blurple()
        )
        
        # Add song details
        embed.add_field(name="Requested by", value=currently_playing['requester'], inline=True)
        embed.add_field(name="Uploader", value=currently_playing['uploader'], inline=True)
        
        # Add source if available
        if 'source' in currently_playing:
            embed.add_field(name="Source", value=currently_playing['source'], inline=True)
        
        # Format duration if available
        if currently_playing['duration']:
            minutes, seconds = divmod(int(currently_playing['duration']), 60)  # Convert to int first
            duration = f"{minutes}:{seconds:02d}"
            embed.add_field(name="Duration", value=duration, inline=True)
        
        # Add thumbnail if available
        if currently_playing['thumbnail']:
            embed.set_thumbnail(url=currently_playing['thumbnail'])
        
        # Add link to the video - adjust label based on source
        if 'source' in currently_playing and currently_playing['source'] != "YouTube":
            embed.add_field(name="Link", value=f"[Open in browser]({currently_playing['url']})", inline=False)
        else:
            embed.add_field(name="Link", value=f"[YouTube]({currently_playing['url']})", inline=False)
        
        # Add radio mode info if enabled
        if hasattr(self.bot, 'radio_mode') and self.bot.radio_mode:
            embed.set_footer(text="Bot is running in radio mode - direct playback unavailable")
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="leave", description="Leave the voice channel")
    async def leave(self, interaction: discord.Interaction):
        """Leave the voice channel"""
        voice_client = self.voice_clients.get(interaction.guild.id)
        if not voice_client:
            await interaction.response.send_message("I'm not connected to a voice channel.")
            return
        
        await self.cleanup(interaction.guild.id)
        await interaction.response.send_message("👋 Left the voice channel.")
    
    @app_commands.command(name="volume", description="Change the player volume (1-100)")
    @app_commands.describe(volume="Volume level (1-100)")
    async def volume(self, interaction: discord.Interaction, volume: int):
        """Change the player volume"""
        if volume < 0 or volume > 100:
            await interaction.response.send_message("Volume must be between 0 and 100.")
            return
        
        voice_client = self.voice_clients.get(interaction.guild.id)
        if not voice_client or not voice_client.is_playing():
            await interaction.response.send_message("Nothing is playing right now.")
            return
        
        # Double the volume for better audio levels
        actual_volume = (volume / 100) * 2.0
        voice_client.source.volume = min(actual_volume, 2.0)  # Cap at 200% to avoid extreme distortion
        
        # Let the user know about the boosted volume
        if volume > 50:
            await interaction.response.send_message(f"🔊 Volume set to {volume}% (boosted for better audio)")
        else:
            await interaction.response.send_message(f"🔊 Volume set to {volume}%")
    
    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        """Handle bot disconnection or being left alone in a voice channel"""
        # If the bot was disconnected
        if member.id == self.bot.user.id and before.channel and not after.channel:
            await self.cleanup(before.channel.guild.id)
            return
            
        # Check if the bot is alone in a voice channel
        if before.channel and member.id != self.bot.user.id:
            voice_client = discord.utils.get(self.bot.voice_clients, channel=before.channel)
            if voice_client and len(before.channel.members) == 1:
                # Only the bot is left in the channel
                await self.cleanup(before.channel.guild.id)
                self.logger.info(f"Left voice channel in {before.channel.guild.name} as bot was alone")

async def setup(bot):
    await bot.add_cog(Music(bot))
